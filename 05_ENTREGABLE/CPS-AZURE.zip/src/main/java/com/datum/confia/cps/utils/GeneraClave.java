package com.datum.confia.cps.utils;

import java.util.Optional;
import java.util.Random;

public class GeneraClave {
	public String getClave(String valor) {

		String clave=null;

		// apartir de una valor se concatenesa un caracter especial y  una aserie de numeros.
		// la longitud noe es tomada encuenta porque esta determinado por el valor mas un caracter especial mas 3 numeros ramdon
		
			String alphabet = "!@#$%^&*()_+=~`,.<>/?':;";
		    int aleatorio = alphabet.length();
		    Random r = new Random();
		    
		    int randomNumeric = (int)(Math.random()*(9999)+1000);
			char randomCaracterEspecial = alphabet.charAt(r.nextInt(aleatorio)); 
			String primerLetraApellido = valor.substring(1, 2);
			String valorClave = valor.replace(primerLetraApellido, primerLetraApellido.toLowerCase() );
			 
			
			clave = valorClave.concat( String.valueOf(randomCaracterEspecial) ).concat( String.valueOf(randomNumeric) );

		return clave;
	}
	
}
