package com.datum.confia.cps.model.entity;

/**
 * 
 * @author dflores
 * undefined se coloca este estado porque cuando se realiza la referecia por numero esta inicia con 0 por locual fue necesariop correr un numero 
 * y para solventar se agrega el estado undefined este no deveria usar segun catalo de estados tabla estados.
 */
public enum EEstado {
	UNDEFINED,
	INGRESADO,
	PENDIENTE,
	ACTUALIZADO,
	FALLADO,
	ANULADO,
	EMPRESA_PENDIENTE_CREAR,
	EMPRESA_CREADA,
	EMPRESA_USUARIO_EXISTE,
	EMPRESA_ERROR_CREACION,
	EMPRESA_REPROCESO_CREAR,
	AFILIADO_PENDIENTE_CREAR,
	AFILIADO_CREADO,
	AFILIADO_USUARIO_EXISTE,
	AFILIADO_ERROR_CREACION,
	AFILIADO_REPROCESO_CREAR
}
